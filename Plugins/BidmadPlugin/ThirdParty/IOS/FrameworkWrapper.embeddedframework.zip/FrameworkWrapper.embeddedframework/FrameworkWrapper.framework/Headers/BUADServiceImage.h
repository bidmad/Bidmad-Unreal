//
//  BUADServiceImage.h
//  BURelyFoundation
//
//  Created by zth on 2022/10/8.
//

#import <Foundation/Foundation.h>
#import "BUADServiceImageProtocol.h"


NS_ASSUME_NONNULL_BEGIN

@interface BUADServiceImage : NSObject <BUADServiceImageProtocol>

@end

NS_ASSUME_NONNULL_END
