//
//  BUADServiceImageModule.h
//  BURelyFoundation
//
//  Created by zth on 2022/10/8.
//

#import "BUADServiceBaseModule.h"

NS_ASSUME_NONNULL_BEGIN

@interface BUADServiceImageModule : BUADServiceBaseModule

@end

NS_ASSUME_NONNULL_END
