//
//  BidmadAdNetworkTestViewController.h
//  OpenBiddingHelper
//
//  Created by Seungsub Oh on 2022/09/07.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BidmadAdNetworkTestViewController : UIViewController

@property (nonatomic, strong) NSString *adNetworkName;

@end

NS_ASSUME_NONNULL_END
