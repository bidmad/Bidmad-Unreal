//
//  UnrealReward.h
//  BidmadSDK
//
//  Created by 전혜연 on 2020/12/08.
//  Copyright © 2020 ADOP Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BIDMADSetting.h"
#import "BIDMADInterstitial.h"

@interface UnrealInterstitial : NSObject <BIDMADInterstitialDelegate>{
    NSString* m_zoneID;
    BIDMADInterstitial* interstitial;
    id<BIDMADInterstitialDelegate> delegate;
}

- (id)init;
- (void)setZoneID:(NSString *)zoneID;
- (void)setDelegate:(id) param;
- (void)load;
- (void)show;
- (bool)isLoaded;
- (bool)isShowing;
- (void)setShowing:(bool) param;

@end
