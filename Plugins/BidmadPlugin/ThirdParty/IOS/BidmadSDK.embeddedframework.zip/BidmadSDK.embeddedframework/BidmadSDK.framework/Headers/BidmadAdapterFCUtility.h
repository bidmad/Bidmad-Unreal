//
//  BidmadAdapterFCUtility.h
//  BidmadAdapterFC
//
//  Created by Kenneth on 2022/06/30.
//

#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"

#import <Foundation/Foundation.h>

@interface BidmadAdapterFCUtility : NSObject
+ (NSString *)BidmadAdapterVersion;

@end


