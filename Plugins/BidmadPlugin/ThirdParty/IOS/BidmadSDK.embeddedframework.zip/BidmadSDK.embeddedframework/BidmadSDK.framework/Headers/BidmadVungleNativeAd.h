//
//  BidmadVungleNativeAd.h
//  BidmadSDK
//
//  Created by Seungsub Oh on 2023/05/04.
//

#import <Foundation/Foundation.h>
#import <ADOPUtility/ADOPUtility.h>

NS_ASSUME_NONNULL_BEGIN

@interface BidmadVungleNativeAd : NSObject <BIDMADNativeAdCommonInterface>

@end

NS_ASSUME_NONNULL_END
