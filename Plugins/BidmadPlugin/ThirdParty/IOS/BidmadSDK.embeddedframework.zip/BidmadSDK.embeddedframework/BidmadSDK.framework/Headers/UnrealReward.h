//
//  UnrealReward.h
//  BidmadSDK
//
//  Created by 전혜연 on 2020/12/08.
//  Copyright © 2020 ADOP Co., Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BIDMADSetting.h"
#import "BIDMADRewardVideo.h"

@interface UnrealReward : NSObject <BIDMADRewardVideoDelegate>{
    NSString* m_zoneID;
    BIDMADRewardVideo* rewardVideo;
    id<BIDMADRewardVideoDelegate> delegate;
}
- (id)init;
- (void)setZoneID:(NSString *)zoneID;
- (void)setDelegate:(id) param;
- (void)load;
- (void)show;
- (bool)isLoaded;
- (bool)isShowing;
- (void)setShowing:(bool) param;

@end
