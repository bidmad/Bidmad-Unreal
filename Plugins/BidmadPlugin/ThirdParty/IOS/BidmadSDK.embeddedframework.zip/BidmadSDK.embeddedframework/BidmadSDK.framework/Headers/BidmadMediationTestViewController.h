//
//  BidmadMediationTestViewController.h
//  BidmadSDK
//
//  Created by Seungsub Oh on 2023/03/02.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BidmadMediationTestViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
