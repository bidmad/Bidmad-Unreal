//
//  NSMutableArray+OK.h
//  OneKit
//
//  Created by bob on 2020/4/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSMutableArray (OK)

- (void)ok_addObject:(nullable id)anObject;

@end

NS_ASSUME_NONNULL_END
