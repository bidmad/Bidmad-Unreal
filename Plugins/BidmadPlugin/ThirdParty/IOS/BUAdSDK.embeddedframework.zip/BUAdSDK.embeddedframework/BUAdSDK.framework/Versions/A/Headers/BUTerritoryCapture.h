//
//  BUTerritoryCapture.h
//  BUAdSDK
//
//  Created by zth on 2022/3/17.
//

/**
 项目环境的判断类
 @Note 更准确的说是设置
 */
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUTerritoryCapture : UICollectionViewCell

+ (BOOL)isCSJ;

@end

NS_ASSUME_NONNULL_END
