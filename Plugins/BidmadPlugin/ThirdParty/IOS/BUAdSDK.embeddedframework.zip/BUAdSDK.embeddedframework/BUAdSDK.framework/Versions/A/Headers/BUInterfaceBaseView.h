//
//  BUInterfaceBaseView.h
//  BUAdSDK
//
//  Created by zth on 2022/3/24.
//

/**
 接口层的基类view
 */
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUInterfaceBaseView : UIView

@end

NS_ASSUME_NONNULL_END
