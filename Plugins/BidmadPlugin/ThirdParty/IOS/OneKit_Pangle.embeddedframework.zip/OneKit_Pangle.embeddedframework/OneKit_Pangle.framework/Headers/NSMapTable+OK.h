//
//  NSMapTable+OK.h
//  OneKit
//
//  Created by bob on 2020/4/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSMapTable (OK)

- (id)ok_safeJsonObject;

@end

NS_ASSUME_NONNULL_END
