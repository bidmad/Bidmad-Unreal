//
//  BidmadAdapterFNCUtility.h
//  BidmadAdapterFNC
//
//  Created by Kenneth on 2022/07/07.
//

#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"

#import <Foundation/Foundation.h>

@interface BidmadAdapterFNCUtility : NSObject
+ (NSString *)BidmadAdapterVersion;

@end
