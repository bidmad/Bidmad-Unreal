//
//  GADMAppLovinExtraAssets.h
//  SDK Network Adapters Test App
//
//  Created by Santosh Bagadi on 4/11/18.
//  Copyright © 2018 AppLovin Corp. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const GADMAppLovinAdID;
extern NSString *const GADMAppLovinCaption;
