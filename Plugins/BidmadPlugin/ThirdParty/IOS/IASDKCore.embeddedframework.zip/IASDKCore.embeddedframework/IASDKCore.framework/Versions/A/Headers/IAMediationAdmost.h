//
//  IAMediationAdmost.h
//  IASDKCore
//
//  Created by Fyber on 14/07/2021.
//  Copyright ©2021 Fyber. All rights reserved.
//

#import <IASDKCore/IASDKCore.h>

NS_ASSUME_NONNULL_BEGIN

@interface IAMediationAdmost : IAMediation

@end

NS_ASSUME_NONNULL_END
