//
//  IAInterfaceContentModel.h
//  IASDKCore
//
//  Created by Fyber on 27/03/2017.
//  Copyright © 2017 Fyber. All rights reserved.
//

#ifndef IAInterfaceContentModel_h
#define IAInterfaceContentModel_h

#import <Foundation/Foundation.h>

@protocol IAInterfaceContentModel  <NSObject, NSCopying>

@end

#endif /* IAInterfaceContentModel_h */
