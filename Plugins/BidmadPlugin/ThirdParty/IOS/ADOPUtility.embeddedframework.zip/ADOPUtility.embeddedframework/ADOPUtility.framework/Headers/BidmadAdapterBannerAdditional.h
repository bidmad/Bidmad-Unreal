//
//  BidmadAdapterBannerAdditional.h
//  BidmadSDK-DevSuite
//
//  Created by ADOP_Mac on 2022/07/01.
//

#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"

@protocol BidmadAdapterBannerAdditional <NSObject>

- (void)setBannerSize:(NSString * _Nonnull)sizeString;
- (void)hide;

@end
