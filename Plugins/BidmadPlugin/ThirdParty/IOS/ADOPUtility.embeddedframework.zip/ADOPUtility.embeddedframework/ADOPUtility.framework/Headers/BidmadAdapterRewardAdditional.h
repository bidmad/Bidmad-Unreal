//
//  BidmadAdapterRewardAdditional.h
//  BidmadSDK-DevSuite
//
//  Created by ADOP_Mac on 2022/07/01.
//

#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"

@protocol BidmadAdapterRewardAdditional <NSObject>

- (void)setIsRewardedAd:(BOOL)isRewardedAd;

@end
