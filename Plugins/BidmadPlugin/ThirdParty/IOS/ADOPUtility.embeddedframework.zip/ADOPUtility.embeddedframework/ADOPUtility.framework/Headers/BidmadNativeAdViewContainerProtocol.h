//
//  BidmadNativeAdViewContainerProtocol.h
//  BidmadSDK-DevSuite
//
//  Created by Seungsub Oh on 2023/02/16.
//

@class BIDMADNativeAdView;

@protocol BidmadNativeAdViewContainerProtocol <NSObject>

@property (nonatomic, weak) BIDMADNativeAdView *adView;

@end
