//
//  PAGNativeRequest.h
//  PAGAdSDK
//
//  Created by bytedance on 2022/3/23.
//

#import "PAGRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface PAGNativeRequest : PAGRequest

@end

NS_ASSUME_NONNULL_END
