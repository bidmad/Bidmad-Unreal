//
//  PAGLInterstitialAdDelegate.h
//  PangleAPI
//
//  Created by bytedance on 2022/2/25.
//

#import "PAGAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@class PAGLInterstitialAd;

@protocol PAGLInterstitialAdDelegate <PAGAdDelegate>

@end

NS_ASSUME_NONNULL_END
