//
//  PAGBannerADDelegate.h
//  PangleAPI
//
//  Created by bytedance on 2022/3/23.
//

#import "PAGAdDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@class PAGBannerAd;

@protocol PAGBannerAdDelegate <PAGAdDelegate>

@end

NS_ASSUME_NONNULL_END
